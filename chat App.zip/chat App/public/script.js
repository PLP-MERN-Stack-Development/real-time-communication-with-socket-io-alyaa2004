const socket = io();

const chatBox = document.querySelector(".chat-messages");
const input = document.querySelector("input");
const sendButton = document.querySelector(".send-btn");
const logoutBtn = document.querySelector(".logout-btn");

const username = sessionStorage.getItem("username") || "Guest";

// Notify server user joined
socket.emit("join", username);


// Append chat message
function appendMessage(data) {

    const msg = document.createElement("div");
    msg.classList.add("message");

    // System message
    if (data.user === "system") {
        msg.classList.add("system");
        msg.innerText = data.text;
    }

    // My message
    else if (data.user === username) {
        msg.classList.add("me");
        msg.innerHTML = `<strong>You:</strong> ${data.text}`;
    }

    // Other users
    else {
        msg.classList.add("other");
        msg.innerHTML = `<strong>${data.user}:</strong> ${data.text}`;
    }

    chatBox.appendChild(msg);
    chatBox.scrollTop = chatBox.scrollHeight;
}


// Receive message from server
socket.on("message", data => {
    appendMessage(data);
});


// Send message
sendButton.addEventListener("click", () => {

    const message = input.value.trim();

    if (!message) return;

    socket.emit("chatMessage", message);

    input.value = "";
});


// Logout
logoutBtn.addEventListener("click", () => {
    sessionStorage.removeItem("username");
    window.location.href = "/";
});
