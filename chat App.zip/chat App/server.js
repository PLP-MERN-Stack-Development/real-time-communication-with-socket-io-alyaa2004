const express = require('express');
const app = express();

const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

let users = {};

io.on("connection", socket => {

    // 🔹 user joins chat
    socket.on('join', username => {

        users[socket.id] = username;

        // رسالة ترحيب ترجع للمستخدم نفسه
        socket.emit("message", {
            user: "system",
            text: `Welcome ${username} 👋`
        });

        // إشعار لباقي المستخدمين
        socket.broadcast.emit("message", {
            user: "system",
            text: `${username} joined the chat`
        });
    });


    // 🔹 chat message event (لاحظ الاسم مطابق للواجهة)
    socket.on('chat-messages', msg => {

        const user = users[socket.id] || "Unknown";

        io.emit('message', {
            user: user,
            text: msg
        });
    });


    // 🔹 disconnect
    socket.on("disconnect", () => {

        const user = users[socket.id];

        if (user) {

            socket.broadcast.emit("message", {
                user: "system",
                text: `${user} left the chat`
            });

            delete users[socket.id];
        }
    });
});


const PORT = 3000;

http.listen(PORT, () => {
    console.log(`Server is on port ${PORT}`);
});
